# Deeplabv3 Pascal Pic
The function of deeplabv3 pascal pic is to perform semantic segmentation on the input image by using the deeplabv3+ model. 

Sample input: jpg picture to be inferred.

Sample output: jpg picture after inference.

```
https://gitee.com/ascend/samples/tree/master/python/level2_simple_inference/3_segmentation/deeplabv3_pascal_pic
```

#### Build docker image

```
docker build -t deeplabv3pascalpic:latest -f ./Dockerfile  .
```

#### Run Docker
```
docker run -p 8000:8000 deeplabv3pascalpic:latest
```
