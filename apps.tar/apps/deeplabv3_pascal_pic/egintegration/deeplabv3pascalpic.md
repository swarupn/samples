Deeplabv3 Pascal Pic
====================
Function: Use the deeplabv3+ model to perform semantic segmentation on the input image.

Reference: https://gitee.com/ascend/samples/tree/master/python/level2_simple_inference/3_segmentation/deeplabv3_pascal_pic

URL
```
POST ascend/v1/deepLabV3PascalPic/input
```

Request parameters:

None

Body parameters:

| Name          | Type                        | Description              | Required      |
| ------------- | --------------------------- | ------------------------ | ------------- |
| image    | file                      | Jpg image file (height and width should be same)| Yes |

Example Request:

'''
curl --location --request POST 'http://{{MEP_IP}}:{{PORT}}/ascend/v1/deepLabV3PascalPic/input' \
--form 'image=@"/C:/Users/LENOVO/OneDrive/Documents/deeplabv3_pascal_pic/cat.jpg"'
'''



Return Parameters:

| Name          | Type                        | Description              |
| ------------- | --------------------------- | ------------------------ |
| outputId     | string                     | Output Id to get the file later                  |

Return Code: 200 OK

Example Response:
```
HTTP/1.1 200 OK
{
    "outputId": "7920c57983a6626a19aa15030f2e5983"
}
```

Exception status code

| HTTP Status Code | Description |
| --- | --- |
| 400  | Bad request, used to indicate that the requested parameters are incorrect. |

URL

```
GET /ascend/v1/deepLabV3PascalPic/output/{outputId}
```

Request parameters:

None

Body parameters:

None

Example Request:

'''
curl --location --request GET 'http://{{MEP_IP}}:{{PORT}}/ascend/v1/deepLabV3PascalPic/output/7920c57983a6626a19aa15030f2e5983'

'''

Return Parameters:

| Name          | Type                        | Description              |
| ------------- | --------------------------- | ------------------------ |
| file     | file                     | output file                |

Return Code: 200 OK

Example Response:
```
HTTP/1.1 200 OK
<<File output>>
```
Exception status code

| HTTP Status Code | Description |
| --- | --- |
| 404  | resource not found. |



URL
```
POST ascend/v1/deepLabV3PascalPic/input
```

Request parameters:

None

Body parameters:

| Name          | Type                        | Description              | Required      |
| ------------- | --------------------------- | ------------------------ | ------------- |
| image    | file                      | Jpg image file (height and width should be same)| Yes |

Example Request:

'''
curl --location --request POST 'http://{{MEP_IP}}:{{PORT}}/ascend/v1/deepLabV3PascalPic/input' \
--form 'image=@"/C:/Users/LENOVO/OneDrive/Documents/deeplabv3_pascal_pic/dog.jpg"'
'''



Return Parameters:

| Name          | Type                        | Description              |
| ------------- | --------------------------- | ------------------------ |
| outputId     | string                     | Output Id to get the file later                  |

Return Code: 200 OK

Example Response:
```
HTTP/1.1 200 OK
{
    "outputId": "d52f88aaa1ba9aa451e0e3ddf1d6cfdd"
}
```

Exception status code

| HTTP Status Code | Description |
| --- | --- |
| 400  | Bad request, used to indicate that the requested parameters are incorrect. |

URL

```
GET /ascend/v1/deepLabV3PascalPic/output/{outputId}
```

Request parameters:

None

Body parameters:

None

Example Request:

'''
curl --location --request GET 'http://{{MEP_IP}}:{{PORT}}/ascend/v1/deepLabV3PascalPic/output/d52f88aaa1ba9aa451e0e3ddf1d6cfdd'
'''

Return Parameters:

| Name          | Type                        | Description              |
| ------------- | --------------------------- | ------------------------ |
| file     | file                     | output file                |

Return Code: 200 OK

Example Response:
```
HTTP/1.1 200 OK
<<File output>>
```
Exception status code

| HTTP Status Code | Description |
| --- | --- |
| 404  | resource not found. |



URL
```
POST ascend/v1/deepLabV3PascalPic/input
```

Request parameters:

None

Body parameters:

| Name          | Type                        | Description              | Required      |
| ------------- | --------------------------- | ------------------------ | ------------- |
| image    | file                      | Jpg image file (height and width should be same)| Yes |

Example Request:

'''
curl --location --request POST 'http://{{MEP_IP}}:{{PORT}}/ascend/v1/deepLabV3PascalPic/input' \
--form 'image=@"/C:/Users/LENOVO/OneDrive/Documents/deeplabv3_pascal_pic/girl.jpg"'
'''



Return Parameters:

| Name          | Type                        | Description              |
| ------------- | --------------------------- | ------------------------ |
| outputId     | string                     | Output Id to get the file later                  |

Return Code: 200 OK

Example Response:
```
HTTP/1.1 200 OK
{
    "outputId": "d00c2ee55469966cfd6476aa38c258f2"
}
```

Exception status code

| HTTP Status Code | Description |
| --- | --- |
| 400  | Bad request, used to indicate that the requested parameters are incorrect. |

URL

```
GET /ascend/v1/deepLabV3PascalPic/output/{outputId}
```

Request parameters:

None

Body parameters:

None

Example Request:

'''
curl --location --request GET 'http://{{MEP_IP}}:{{PORT}}/ascend/v1/deepLabV3PascalPic/output/d00c2ee55469966cfd6476aa38c258f2'
'''

Return Parameters:

| Name          | Type                        | Description              |
| ------------- | --------------------------- | ------------------------ |
| file     | file                     | output file                |

Return Code: 200 OK

Example Response:
```
HTTP/1.1 200 OK
<<File output>>
```
Exception status code

| HTTP Status Code | Description |
| --- | --- |
| 404  | resource not found. |