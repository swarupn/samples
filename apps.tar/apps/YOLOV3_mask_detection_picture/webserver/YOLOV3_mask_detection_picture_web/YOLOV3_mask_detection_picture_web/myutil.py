import uuid,hashlib
import os,shutil
from . import settings

def get_unique_str():
    uuid_str = str(uuid.uuid4())
    md5 = hashlib.md5()
    md5.update(uuid_str.encode('utf-8'))
    return md5.hexdigest()

def mask_detect_pic():
    cmd = 'cd ' + settings.OUT_PATH + ' && python3 mask_detect.py'
    print(cmd)
    os.system(cmd)
    
def clear_dir(filepaths):
    for filepath in filepaths:
        if not os.path.exists(filepath):
            os.mkdir(filepath)
        else:
            shutil.rmtree(filepath)
            os.mkdir(filepath)

def get_output_file(path, filename_prefix):
    for file in os.listdir(path):
        if file.startswith(filename_prefix):
            return os.path.join(path, file)
    return None

    

