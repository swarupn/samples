# YOLOV3 mask Detection Picture
The function of yolov3 mask detection picture is to detect the face and face mask in an image, and recognizes the masked face.


```
https://gitee.com/ascend/samples/tree/master/python/level2_simple_inference/2_object_detection/YOLOV3_mask_detection_picture
```

#### Build docker image

```
docker build -t yolov3maskdetectionpicture:latest -f ./Dockerfile  .
```

#### Run Docker
```
docker run -p 8000:8000 yolov3maskdetectionpicture:latest
```
