YOLOV3 Mask Detection Picture
=============================
Function: Detects the face and face mask in an image, and recognizes the masked face.

Reference: https://gitee.com/ascend/samples/tree/master/python/level2_simple_inference/2_object_detection/YOLOV3_mask_detection_picture

URL
```
POST ascend/v1/yoloV3MaskDetectionPicture/input
```

Request parameters:

None

Body parameters:

| Name          | Type                        | Description              | Required      |
| ------------- | --------------------------- | ------------------------ | ------------- |
| image    | file                      | Jpeg image file (height and width should be same)| Yes |

Example Request:

curl --location --request POST 'http://{{MEP_IP}}:{{PORT}}/ascend/v1/yoloV3MaskDetectionPicture/input' \
--form 'image=@"/C:/Users/LENOVO/OneDrive/Documents/YOLOV3_mask_detection_picture/mask.jpg"'


Return Parameters:

| Name          | Type                        | Description              |
| ------------- | --------------------------- | ------------------------ |
| outputId     | string                     | Output Id to get the file later                  |

Return Code: 200 OK

Example Response:
```
HTTP/1.1 200 OK
{
    "outputId": "7a4d1972350e6d9796aef3773a760ecf"
}
```

Exception status code

| HTTP Status Code | Description |
| --- | --- |
| 400  | Bad request, used to indicate that the requested parameters are incorrect. |

URL

```
GET /ascend/v1/yoloV3MaskDetectionPicture/output/{outputId}
```

Request parameters:

None

Body parameters:

None

Example Request:

curl --location --request GET 'http://{{MEP_IP}}:{{PORT}}/ascend/v1/yoloV3MaskDetectionPicture/output/7a4d1972350e6d9796aef3773a760ecf'



Return Parameters:

| Name          | Type                        | Description              |
| ------------- | --------------------------- | ------------------------ |
| file     | file                     | output file                |

Return Code: 200 OK

Example Response:
```
HTTP/1.1 200 OK
<<File output>>
```
Exception status code

| HTTP Status Code | Description |
| --- | --- |
| 404  | resource not found. |

