from django.http import HttpResponse
from . import settings
from . import myutil
import os
import json
import traceback
import mimetypes

def convert(req):
    if not req.method == 'POST':
        response = HttpResponse(status=405)
        response.__setitem__('Access-Control-Allow-Origin', '*')
        return response
    try:
        myfile = req.FILES.get('file')
        myfile.name
        filesuffix = myutil.get_unique_str()
        filename = filesuffix +'.'+ myfile.name.split('.')[-1]
        print('the filename is :' + filename)

        filepath = os.path.join(settings.MEDIA_ROOT, filename)
        print('the filepath is :' + filepath)

        f = open(filepath,'wb')
        for i in myfile.chunks():
            f.write(i)
        f.close()

        converted_file_name = myutil.convert_pic(filepath)
        converted_file = settings.OUTPUT_PATH + converted_file_name
        print('the final image is :' + converted_file)
        response_data = {}
        response_data['outputId'] = filesuffix
        response = HttpResponse(json.dumps(response_data), content_type="application/json")
        response.__setitem__('Access-Control-Allow-Origin', '*')
        return response
    except:
        traceback.print_exc()
        response = HttpResponse('Bad Request', status=400)
        response.__setitem__('Access-Control-Allow-Origin', '*')
        return response

def DownLoadApiView(request, param):
    if request.method == "GET":
        print('DownLoadApiView param ' + param)
        for file in os.listdir(settings.OUTPUT_PATH):
            if file.startswith(param + "."):
                filename = file
                filepath = os.path.join(settings.OUTPUT_PATH, filename)
                fileOpen = open(filepath, 'rb')
                response = HttpResponse(fileOpen)
                response['Content-Type'] = 'application/octet-stream'  
                response['Content-Disposition'] = 'attachment;filename="dst.jpg"'
                response.__setitem__('Access-Control-Allow-Origin', '*')
                return response
        response = HttpResponse('Resource not found', status=404)
        response.__setitem__('Access-Control-Allow-Origin', '*')
        return response