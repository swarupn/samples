Gesture Recognition Picture
===========================
Function: recognizes gestures in an input image by using the gesture_yuv model.

Reference: https://gitee.com/ascend/samples/tree/master/python/contrib/gesture_recognition_picture

URL
```
POST ascend/v1/gestureRecognitionPicture/input
```

Request parameters:

None

Body parameters:

| Name          | Type                        | Description              | Required      |
| ------------- | --------------------------- | ------------------------ | ------------- |
| image    | file                      | Jpg image file (height and width should be same)| Yes |

Example Request:

'''
curl --location --request POST 'http://{{MEP_IP}}:{{PORT}}/ascend/v1/gestureRecognitionPicture/input' \
--form 'image=@"/C:/Users/LENOVO/OneDrive/Documents/gesture_recognition_picture/test1.jpg"'
'''



Return Parameters:

| Name          | Type                        | Description              |
| ------------- | --------------------------- | ------------------------ |
| outputId     | string                     | Output Id to get the file later                  |

Return Code: 200 OK

Example Response:
```
HTTP/1.1 200 OK
{
    "outputId": "ce6c4936f2ab4bb26deb6e7277c4e678"
}
```

Exception status code

| HTTP Status Code | Description |
| --- | --- |
| 400  | Bad request, used to indicate that the requested parameters are incorrect. |

URL

```
GET /ascend/v1/gestureRecognitionPicture/output/{outputId}
```

Request parameters:

None

Body parameters:

None

Example Request:

'''
curl --location --request GET 'http://{{MEP_IP}}:{{PORT}}/ascend/v1/gestureRecognitionPicture/output/ce6c4936f2ab4bb26deb6e7277c4e678' 

'''

Return Parameters:

| Name          | Type                        | Description              |
| ------------- | --------------------------- | ------------------------ |
| file     | file                     | output file                |

Return Code: 200 OK

Example Response:
```
HTTP/1.1 200 OK
<<File output>>
```
Exception status code

| HTTP Status Code | Description |
| --- | --- |
| 404  | resource not found. |



URL
```
POST ascend/v1/gestureRecognitionPicture/input
```

Request parameters:

None

Body parameters:

| Name          | Type                        | Description              | Required      |
| ------------- | --------------------------- | ------------------------ | ------------- |
| image    | file                      | Jpg image file (height and width should be same)| Yes |

Example Request:

'''
curl --location --request POST 'http://{{MEP_IP}}:{{PORT}}/ascend/v1/gestureRecognitionPicture/input' \
--form 'image=@"/C:/Users/LENOVO/OneDrive/Documents/gesture_recognition_picture/test2.jpg"'
'''



Return Parameters:

| Name          | Type                        | Description              |
| ------------- | --------------------------- | ------------------------ |
| outputId     | string                     | Output Id to get the file later                  |

Return Code: 200 OK

Example Response:
```
HTTP/1.1 200 OK
{
    "outputId": "0d6f3e015954397b949228f425944ff9"
}
```

Exception status code

| HTTP Status Code | Description |
| --- | --- |
| 400  | Bad request, used to indicate that the requested parameters are incorrect. |

URL

```
GET /ascend/v1/gestureRecognitionPicture/output/{outputId}
```

Request parameters:

None

Body parameters:

None

Example Request:

'''
curl --location --request GET 'http://{{MEP_IP}}:{{PORT}}/ascend/v1/gestureRecognitionPicture/output/0d6f3e015954397b949228f425944ff9'
'''

Return Parameters:

| Name          | Type                        | Description              |
| ------------- | --------------------------- | ------------------------ |
| file     | file                     | output file                |

Return Code: 200 OK

Example Response:
```
HTTP/1.1 200 OK
<<File output>>
```
Exception status code

| HTTP Status Code | Description |
| --- | --- |
| 404  | resource not found. |



URL
```
POST ascend/v1/gestureRecognitionPicture/input
```

Request parameters:

None

Body parameters:

| Name          | Type                        | Description              | Required      |
| ------------- | --------------------------- | ------------------------ | ------------- |
| image    | file                      | Jpg image file (height and width should be same)| Yes |

Example Request:

'''
curl --location --request POST 'http://{{MEP_IP}}:{{PORT}}/ascend/v1/gestureRecognitionPicture/input' \
--form 'image=@"/C:/Users/LENOVO/OneDrive/Documents/gesture_recognition_picture/test3.jpg"'
'''



Return Parameters:

| Name          | Type                        | Description              |
| ------------- | --------------------------- | ------------------------ |
| outputId     | string                     | Output Id to get the file later                  |

Return Code: 200 OK

Example Response:
```
HTTP/1.1 200 OK
{
    "outputId": "cc40ab8d41994cc72370c60f409ada64"
}
```

Exception status code

| HTTP Status Code | Description |
| --- | --- |
| 400  | Bad request, used to indicate that the requested parameters are incorrect. |

URL

```
GET /ascend/v1/gestureRecognitionPicture/output/{outputId}
```

Request parameters:

None

Body parameters:

None

Example Request:

'''
curl --location --request GET 'http://{{MEP_IP}}:{{PORT}}/ascend/v1/gestureRecognitionPicture/output/cc40ab8d41994cc72370c60f409ada64'
'''

Return Parameters:

| Name          | Type                        | Description              |
| ------------- | --------------------------- | ------------------------ |
| file     | file                     | output file                |

Return Code: 200 OK

Example Response:
```
HTTP/1.1 200 OK
<<File output>>
```
Exception status code

| HTTP Status Code | Description |
| --- | --- |
| 404  | resource not found. |