# Gesture Recognition Picture
The function of gesture recognition picture is to recognise gestures in an input image by using the gesture_yuv model.


```
https://gitee.com/ascend/samples/tree/master/python/contrib/gesture_recognition_picture
```

#### Build docker image

```
docker build -t gesturerecognitionpicture:latest -f ./Dockerfile  .
```

#### Run Docker
```
docker run -p 31011:8006 gesturerecognitionpicture:latest
```
