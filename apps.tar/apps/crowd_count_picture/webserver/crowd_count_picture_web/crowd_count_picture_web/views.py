from django.http import HttpResponse
from . import settings
from . import myutil
import os
import json
import traceback

 
def crowd(req):
    if not req.method == 'POST':
        response = HttpResponse(status=405)
        response.__setitem__('Access-Control-Allow-Origin', '*')
        return response
    try:
        filepaths = [settings.DATA_PATH, settings.OUTPUT_PATH]
        myutil.clear_dir(filepaths)
        
        myfile = req.FILES.get('image')
        file_prefix = myutil.get_unique_str()
        filename = file_prefix + '.' + myfile.name.split('.')[-1]

        filepath = os.path.join(settings.DATA_PATH, filename)
        f = open(filepath,'wb')
        for i in myfile.chunks():
            f.write(i)
        f.close()
        try:
            myutil.crowd_count_pic()
        except Exception as e:
            traceback.print_exc()
            response = HttpResponse(status=500, reason=repr(e))
            response.__setitem__('Access-Control-Allow-Origin', '*')
            return response

        if myutil.get_output_file(settings.OUTPUT_PATH, file_prefix + ".") is None:
            response = HttpResponse(status=500, reason="Inference error, input file format may be wrong")
            response.__setitem__('Access-Control-Allow-Origin', '*')
            return response

        response_data = {'outputId': file_prefix}
        response = HttpResponse(json.dumps(response_data), content_type="application/json")
        response.__setitem__('Access-Control-Allow-Origin', '*')
        return response
    except:
        traceback.print_exc()
        response = HttpResponse('Bad Request', status=400) 
        response.__setitem__('Access-Control-Allow-Origin', '*')
        return response  

def download_result(request, param):
    if request.method == "GET":
        file_path = myutil.get_output_file(settings.OUTPUT_PATH, param + ".")
        if file_path is None:
            return HttpResponse(status=404)
        file_open = open(file_path, 'rb')
        response = HttpResponse(file_open)
        response['Content-Type'] = 'application/octet-stream'
        response['Content-Disposition'] = 'attachment;filename="output.jpg"'
        response.__setitem__('Access-Control-Allow-Origin', '*')
        return response
    else:
        response = HttpResponse(status=405)
        response.__setitem__('Access-Control-Allow-Origin', '*')
        return response