# Crowd Count Picture
The function of Crowd Count Picture is to count people using the count_person.caffe model. For example, given the crowd image, our model is able to count the people present in the image which mean getting an image marked with number.

Input: a crowd image

Output: an image marked with numbers

```
https://gitee.com/ascend/samples/tree/master/python/contrib/crowd_count_picture
```

#### Build docker image

```
docker build -t crowdcountpicture:latest -f ./Dockerfile  .
```

#### Run Docker
```
docker run -p 8000:8000 crowdcountpicture:latest
```
