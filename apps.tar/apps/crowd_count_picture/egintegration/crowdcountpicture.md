Crowd Count Picture
===================
Function: To count people in an image using the count_person.caffe model.

Reference: https://gitee.com/ascend/samples/tree/master/python/contrib/crowd_count_picture

URL
```
POST ascend/v1/crowdCountPicture/input
```

Request parameters:

None

Body parameters:

| Name          | Type                        | Description              | Required      |
| ------------- | --------------------------- | ------------------------ | ------------- |
| image    | file                      | Jpeg image file (height and width should be same)| Yes |

Example Request:

curl --location --request POST 'http://{{MEP_IP}}:{{PORT}}/ascend/v1/crowdCountPicture/input' \
--form 'image=@"/C:/Users/LENOVO/OneDrive/Documents/crowd.jpg"'


Return Parameters:

| Name          | Type                        | Description              |
| ------------- | --------------------------- | ------------------------ |
| outputId     | string                     | Output Id to get the file later                  |

Return Code: 200 OK

Example Response:
```
HTTP/1.1 200 OK
{
    "outputId": "35b33e5655c45152c32d76a4508edf3c"
}
```

Exception status code

| HTTP Status Code | Description |
| --- | --- |
| 400  | Bad request, used to indicate that the requested parameters are incorrect. |

URL

```
GET /ascend/v1/crowdCountPicture/output/{outputId}
```

Request parameters:

None

Body parameters:

None

Example Request:

curl --location --request GET 'http://{{MEP_IP}}:{{PORT}}/ascend/v1/crowdCountPicture/output/35b33e5655c45152c32d76a4508edf3c'



Return Parameters:

| Name          | Type                        | Description              |
| ------------- | --------------------------- | ------------------------ |
| file     | file                     | output file                |

Return Code: 200 OK

Example Response:
```
HTTP/1.1 200 OK
<<File output>>
```
Exception status code

| HTTP Status Code | Description |
| --- | --- |
| 404  | resource not found. |

