# DeRain
The function of DeRain is to read the local rain degraded image data, the rain line, rain and fog in the scene can be removed to realize the image enhancement effect.

Input: original picture png file.

Output: png file with inference results.

```
https://gitee.com/ascend/samples/tree/master/cplusplus/level2_simple_inference/6_other/DeRain
```

#### Build docker image

```
docker build -t derain:latest -f ./Dockerfile  .
```

#### Run Docker
```
docker run -p 8000:8000 derain:latest
```
